package com.alex.store;

public class FileReference {
   private int nameHash;

   public int getNameHash() {
      return this.nameHash;
   }

   public void setNameHash(int nameHash) {
      this.nameHash = nameHash;
   }
}
