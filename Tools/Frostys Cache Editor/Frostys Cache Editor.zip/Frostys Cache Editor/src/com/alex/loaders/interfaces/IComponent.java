package com.alex.loaders.interfaces;

import com.alex.io.InputStream;
import com.alex.loaders.interfaces.IComponentSettings;

public class IComponent {
   public Object[] anObjectArray2296;
   public int anInt2297 = 0;
   public int anInt2298 = -1;
   public int[] anIntArray2299;
   public int anInt2300;
   public int anInt2301 = 1;
   public Object[] anObjectArray2302;
   public int anInt2303 = -1;
   public int anInt2305 = 0;
   public boolean aBoolean2306 = false;
   public int anInt2308 = 0;
   public int[] anIntArray2310;
   public byte aByte2311 = 0;
   public int anInt2312 = 0;
   public Object[] anObjectArray2313;
   public int anInt2314;
   public int[] anIntArray2315;
   public Object[] anObjectArray2316;
   public byte[] aByteArray2317;
   public Object[] anObjectArray2318;
   public int anInt2319 = 0;
   public int anInt2321 = -1;
   public int height = 0;
   public int[] anIntArray2323;
   public int anInt2324 = 0;
   public int anInt2325 = 0;
   public IComponent[] aClass173Array2326;
   public int[][] anIntArrayArray2327;
   public Object[] anObjectArray2328;
   public String aString2329 = "Ok";
   public String aString2330;
   public Object[] anObjectArray2331;
   public int anInt2332 = 0;
   public int anInt2333 = 0;
   public String aString2334 = "";
   public int anInt2335 = 0;
   public Object[] anObjectArray2336;
   public int[] anIntArray2337;
   public int anInt2338 = 0;
   public int anInt2340;
   public byte aByte2341 = 0;
   public boolean aBoolean2342;
   public int anInt2343 = 0;
   public Object[] anObjectArray2344;
   public IComponent aClass173_2345 = null;
   public static int anInt2346;
   public int anInt2347 = 0;
   public Object[] anObjectArray2348;
   public int anInt2349 = -1;
   public int anInt2350 = -1;
   public Object[] anObjectArray2351;
   public Object[] anObjectArray2352;
   public boolean aBoolean2353 = false;
   public boolean useScripts = false;
   public byte aByte2356 = 0;
   public String aString2357 = "";
   public int modelId;
   public int[] anIntArray2360;
   public int anInt2361 = -1;
   public Object[] anObjectArray2362;
   public String[] aStringArray2363;
   public int anInt2364 = 0;
   public int anInt2365 = -1;
   public boolean aBoolean2366 = false;
   public boolean aBoolean2367 = false;
   public boolean aBoolean2368 = false;
   public int anInt2369 = 0;
   public Object[] anObjectArray2371;
   public String aString2373 = "";
   public int anInt2374 = -1;
   public int anInt2375 = -1;
   public int imageId = -1;
   public int[] anIntArray2379;
   public boolean aBoolean2380 = false;
   public int anInt2381 = 0;
   public int anInt2382;
   public short aShort2383 = 0;
   public int[] anIntArray2384;
   public String[] aStringArray2385;
   public int anInt2386 = -1;
   public int[] anIntArray2388;
   public int anInt2389 = 0;
   public int anInt2390 = 0;
   public String aString2391 = "";
   public boolean aBoolean2393 = false;
   public int anInt2394 = 1;
   public Object[] anObjectArray2395;
   public int anInt2396 = 0;
   public int anInt2397 = 0;
   public IComponentSettings settings;
   public Object[] anObjectArray2399;
   public int[] anIntArray2400;
   public boolean aBoolean2401 = false;
   public Object[] anObjectArray2402;
   public int anInt2403 = 100;
   public boolean hidden = false;
   public Object[] anObjectArray2405;
   public int[] anIntArray2407;
   public Object[] anObjectArray2408;
   public int anInt2409;
   public Object[] anObjectArray2410;
   public int anInt2411 = 0;
   public int anInt2412 = 0;
   public boolean aBoolean2413 = false;
   public int anInt2414 = 0;
   public int anInt2415 = 0;
   public int modelType = 1;
   public byte[] aByteArray2417;
   public int[] anIntArray2418;
   public boolean aBoolean2419;
   public short aShort2420 = 3000;
   public int anInt2421 = -1;
   public boolean aBoolean2422 = false;
   public int anInt2423 = 0;
   public int anInt2424 = 0;
   public Object[] defaultScript;
   public int anInt2427 = 0;
   public boolean aBoolean2429 = false;
   public int[] anIntArray2431;
   public int y = 0;
   public int borderThickness = 0;
   public boolean aBoolean2434 = false;
   public int anInt2435 = 0;
   public boolean aBoolean2436 = false;
   public int anInt2437 = 0;
   public int anInt2438 = 1;
   public Object[] anObjectArray2439;
   public int width = 0;
   public int anInt2441 = 0;
   public int anInt2442 = 0;
   public int anInt2443 = -1;
   public int anInt2444 = 0;
   public int x = 0;
   public Object[] anObjectArray2446;
   public Object[] anObjectArray2447;
   public int anInt2448 = -1;
   public int[] anIntArray2449;
   public int anInt2450 = 0;
   public int anInt2451 = 0;
   public int[] anIntArray2452;
   public int anInt2453 = -1;
   public Object[] anObjectArray2454;
   public int hash = -1;
   public int parentId = -1;
   public int anInt2457 = -1;
   public int anInt2458;
   public int anInt2459 = 0;
   public int anInt2461 = 0;
   public Object[] anObjectArray2462;
   public String aString2463 = "";
   public Object[] anObjectArray2464;
   public Object[] anObjectArray2465;
   public int anInt2467 = 0;
   public byte aByte2469 = 0;
   public int type;
   public int anInt2471 = 1;
   public int[] anIntArray2472;
   public String aString2473;
   public int anInt2474 = 2;
   public Object[] anObjectArray2475;
   public boolean aBoolean2476 = false;
   public int anInt2477 = 0;
   public int[] anIntArray2478;
   public int anInt2479 = 0;
   public int anInt2480 = 0;
   public int anInt2481 = 1;
   public int anInt2482 = 0;
   public Object[] anObjectArray2483;
   public int anInt2484 = 0;
   public boolean aBoolean4782;

   public void decodeScriptsFormat(InputStream stream) {
      this.useScripts = true;
      int newInt = stream.readUnsignedByte();
      if(newInt == 255) {
         newInt = -1;
      }

      this.type = stream.readUnsignedByte();
      if(~(this.type & 128) != -1) {
         this.type &= 127;
         this.aString2473 = stream.readString();
      }

      this.anInt2441 = stream.readUnsignedShort();
      this.x = stream.readShort();
      this.y = stream.readShort();
      this.width = stream.readUnsignedShort();
      this.height = stream.readUnsignedShort();
      this.aByte2356 = (byte)stream.readByte();
      this.aByte2341 = (byte)stream.readByte();
      this.aByte2469 = (byte)stream.readByte();
      this.aByte2311 = (byte)stream.readByte();
      this.parentId = stream.readUnsignedShort();
      if(~this.parentId != -65536) {
         this.parentId += this.hash & -65536;
      } else {
         this.parentId = -1;
      }

      int i_17_ = stream.readUnsignedByte();
      this.hidden = ~(1 & i_17_) != -1;
      if(newInt >= 0) {
         this.aBoolean2429 = ~(i_17_ & 2) != -1;
      }

      if(~this.type == -1) {
         this.anInt2444 = stream.readUnsignedShort();
         this.anInt2479 = stream.readUnsignedShort();
         if(~newInt > -1) {
            this.aBoolean2429 = stream.readUnsignedByte() == 1;
         }
      }

      int settingsHash;
      if(~this.type == -6) {
         this.imageId = stream.readInt();
         this.anInt2381 = stream.readUnsignedShort();
         settingsHash = stream.readUnsignedByte();
         this.aBoolean2422 = ~(2 & settingsHash) != -1;
         this.aBoolean2434 = ~(settingsHash & 1) != -1;
         this.anInt2369 = stream.readUnsignedByte();
         this.borderThickness = stream.readUnsignedByte();
         this.anInt2325 = stream.readInt();
         this.aBoolean2419 = ~stream.readUnsignedByte() == -2;
         this.aBoolean2342 = ~stream.readUnsignedByte() == -2;
         this.anInt2467 = stream.readInt();
         if(~newInt <= -4) {
            this.aBoolean4782 = ~stream.readUnsignedByte() == -2;
         }
      }

      if(~this.type == -7) {
         this.modelType = 1;
         this.modelId = stream.readBigSmart();
         this.anInt2480 = stream.readShort();
         this.anInt2459 = stream.readShort();
         this.anInt2461 = stream.readUnsignedShort();
         this.anInt2482 = stream.readUnsignedShort();
         this.anInt2308 = stream.readUnsignedShort();
         this.anInt2403 = stream.readUnsignedShort();
         this.anInt2443 = stream.readUnsignedShort();
         if(this.anInt2443 == '\uffff') {
            this.anInt2443 = -1;
         }

         this.aBoolean2476 = stream.readUnsignedByte() == 1;
         this.aShort2383 = (short)stream.readUnsignedShort();
         this.aShort2420 = (short)stream.readUnsignedShort();
         this.aBoolean2368 = stream.readUnsignedByte() == 1;
         if(~this.aByte2356 != -1) {
            this.anInt2423 = stream.readUnsignedShort();
         }

         if(this.aByte2341 != 0) {
            this.anInt2397 = stream.readUnsignedShort();
         }
      }

      if(this.type == 4) {
         this.anInt2375 = stream.readBigSmart();
         if(~this.anInt2375 == -65536) {
            this.anInt2375 = -1;
         }

         this.aString2357 = stream.readString();
         if(this.aString2357.toLowerCase().contains("ship")) {
            System.out.println(this.hash >> 16);
         }

         this.anInt2364 = stream.readUnsignedByte();
         this.anInt2312 = stream.readUnsignedByte();
         this.anInt2297 = stream.readUnsignedByte();
         this.aBoolean2366 = ~stream.readUnsignedByte() == -2;
         this.anInt2467 = stream.readInt();
      }

      if(this.type == 3) {
         this.anInt2467 = stream.readInt();
         this.aBoolean2367 = ~stream.readUnsignedByte() == -2;
         this.anInt2369 = stream.readUnsignedByte();
      }

      if(~this.type == -10) {
         this.anInt2471 = stream.readUnsignedByte();
         this.anInt2467 = stream.readInt();
         this.aBoolean2306 = ~stream.readUnsignedByte() == -2;
      }

      settingsHash = stream.read24BitInt();
      int i_28_ = stream.readUnsignedByte();
      int i_30_;
      if(i_28_ != 0) {
         this.anIntArray2449 = new int[11];
         this.aByteArray2417 = new byte[11];

         for(this.aByteArray2317 = new byte[11]; ~i_28_ != -1; i_28_ = stream.readUnsignedByte()) {
            i_30_ = -1 + (i_28_ >> 360744868);
            i_28_ = i_28_ << -456693784 | stream.readUnsignedByte();
            i_28_ &= 4095;
            if(~i_28_ != -4096) {
               this.anIntArray2449[i_30_] = i_28_;
            } else {
               this.anIntArray2449[i_30_] = -1;
            }

            this.aByteArray2317[i_30_] = (byte)stream.readByte();
            if(~this.aByteArray2317[i_30_] != -1) {
               this.aBoolean2401 = true;
            }

            this.aByteArray2417[i_30_] = (byte)stream.readByte();
         }
      }

      this.aString2391 = stream.readString();
      i_30_ = stream.readUnsignedByte();
      int i_31_ = i_30_ & 15;
      int i_33_;
      if(~i_31_ < -1) {
         this.aStringArray2385 = new String[i_31_];

         for(i_33_ = 0; i_31_ > i_33_; ++i_33_) {
            this.aStringArray2385[i_33_] = stream.readString();
         }
      }

      i_33_ = i_30_ >> -686838332;
      int defaultHash;
      int i;
      if(~i_33_ < -1) {
         defaultHash = stream.readUnsignedByte();
         this.anIntArray2315 = new int[1 + defaultHash];

         for(i = 0; i < this.anIntArray2315.length; ++i) {
            this.anIntArray2315[i] = -1;
         }

         this.anIntArray2315[defaultHash] = stream.readUnsignedShort();
      }

      if(~i_33_ < -2) {
         defaultHash = stream.readUnsignedByte();
         this.anIntArray2315[defaultHash] = stream.readUnsignedShort();
      }

      this.aString2330 = stream.readString();
      if(this.aString2330.equals("")) {
         this.aString2330 = null;
      }

      this.anInt2335 = stream.readUnsignedByte();
      this.anInt2319 = stream.readUnsignedByte();
      this.aBoolean2436 = ~stream.readUnsignedByte() == -2;
      this.aString2463 = stream.readString();
      defaultHash = -1;
      if(~method2412(settingsHash) != -1) {
         defaultHash = stream.readUnsignedShort();
         if(~defaultHash == -65536) {
            defaultHash = -1;
         }

         this.anInt2303 = stream.readUnsignedShort();
         if(this.anInt2303 == '\uffff') {
            this.anInt2303 = -1;
         }

         this.anInt2374 = stream.readUnsignedShort();
         if(this.anInt2374 == '\uffff') {
            this.anInt2374 = -1;
         }
      }

      this.settings = new IComponentSettings(settingsHash, defaultHash);
      this.defaultScript = this.decodeScript(stream);
      this.anObjectArray2462 = this.decodeScript(stream);
      this.anObjectArray2402 = this.decodeScript(stream);
      this.anObjectArray2371 = this.decodeScript(stream);
      this.anObjectArray2408 = this.decodeScript(stream);
      this.anObjectArray2439 = this.decodeScript(stream);
      this.anObjectArray2454 = this.decodeScript(stream);
      this.anObjectArray2410 = this.decodeScript(stream);
      this.anObjectArray2316 = this.decodeScript(stream);
      this.anObjectArray2465 = this.decodeScript(stream);
      this.anObjectArray2446 = this.decodeScript(stream);
      this.anObjectArray2313 = this.decodeScript(stream);
      this.anObjectArray2318 = this.decodeScript(stream);
      this.anObjectArray2328 = this.decodeScript(stream);
      this.anObjectArray2395 = this.decodeScript(stream);
      this.anObjectArray2331 = this.decodeScript(stream);
      this.anObjectArray2405 = this.decodeScript(stream);
      this.anObjectArray2351 = this.decodeScript(stream);
      this.anObjectArray2302 = this.decodeScript(stream);
      this.anObjectArray2296 = this.decodeScript(stream);
      this.anIntArray2452 = this.method2465(stream);
      this.anIntArray2472 = this.method2465(stream);
      this.anIntArray2360 = this.method2465(stream);
      this.anIntArray2388 = this.method2465(stream);
      this.anIntArray2299 = this.method2465(stream);
      System.out.println("useScripts = " + this.useScripts);
      System.out.println("x = " + this.x);
      System.out.println("y = " + this.y);
      System.out.println("width = " + this.width);
      System.out.println("height = " + this.height);
      System.out.println("parentId = " + this.parentId);
      System.out.println("imageId = " + this.imageId);
      System.out.println("modelId = " + this.modelId);
      System.out.println("aString2357 = " + this.aString2357);
      System.out.println("aString2391 = " + this.aString2391);

      for(i = 0; i < this.aStringArray2385.length; ++i) {
         System.out.println("aStringArray2385[" + i + "] = " + this.aStringArray2385[i]);
      }

      for(i = 0; i < this.anIntArray2315.length; ++i) {
         System.out.println("anIntArray2315[" + i + "] = " + this.anIntArray2315[i]);
      }

      System.out.println("aString2330 = " + this.aString2330);
      System.out.println("aBoolean2436 = " + this.aBoolean2436);
      System.out.println("aString2463 = " + this.aString2463);
      System.out.println("anInt2303 = " + this.anInt2303);
      System.out.println("anInt2364 = " + this.anInt2364);

      for(i = 0; i < this.anObjectArray2462.length; ++i) {
         System.out.println("anObjectArray2462[" + i + "] = " + this.anObjectArray2462[i]);
      }

      for(i = 0; i < this.anObjectArray2402.length; ++i) {
         System.out.println("anObjectArray2402[" + i + "] = " + this.anObjectArray2402[i]);
      }

      for(i = 0; i < this.anObjectArray2371.length; ++i) {
         System.out.println("anObjectArray2371[" + i + "] = " + this.anObjectArray2371[i]);
      }

      for(i = 0; i < this.anObjectArray2408.length; ++i) {
         System.out.println("anObjectArray2408[" + i + "] = " + this.anObjectArray2408[i]);
      }

      for(i = 0; i < this.anObjectArray2439.length; ++i) {
         System.out.println("anObjectArray2439[" + i + "] = " + this.anObjectArray2439[i]);
      }

      for(i = 0; i < this.anObjectArray2454.length; ++i) {
         System.out.println("anObjectArray2454[" + i + "] = " + this.anObjectArray2454[i]);
      }

      for(i = 0; i < this.anObjectArray2410.length; ++i) {
         System.out.println("anObjectArray2410[" + i + "] = " + this.anObjectArray2410[i]);
      }

      for(i = 0; i < this.anObjectArray2316.length; ++i) {
         System.out.println("anObjectArray2316[" + i + "] = " + this.anObjectArray2316[i]);
      }

      for(i = 0; i < this.anObjectArray2465.length; ++i) {
         System.out.println("anObjectArray2465[" + i + "] = " + this.anObjectArray2465[i]);
      }

      for(i = 0; i < this.anObjectArray2446.length; ++i) {
         System.out.println("anObjectArray2446[" + i + "] = " + this.anObjectArray2446[i]);
      }

      for(i = 0; i < this.anObjectArray2313.length; ++i) {
         System.out.println("anObjectArray2313[" + i + "] = " + this.anObjectArray2313[i]);
      }

      for(i = 0; i < this.anObjectArray2318.length; ++i) {
         System.out.println("anObjectArray2318[" + i + "] = " + this.anObjectArray2318[i]);
      }

      for(i = 0; i < this.anObjectArray2328.length; ++i) {
         System.out.println("anObjectArray2328[" + i + "] = " + this.anObjectArray2328[i]);
      }

      for(i = 0; i < this.anObjectArray2395.length; ++i) {
         System.out.println("anObjectArray2395[" + i + "] = " + this.anObjectArray2395[i]);
      }

      for(i = 0; i < this.anObjectArray2331.length; ++i) {
         System.out.println("anObjectArray2331[" + i + "] = " + this.anObjectArray2331[i]);
      }

      for(i = 0; i < this.anObjectArray2405.length; ++i) {
         System.out.println("anObjectArray2405[" + i + "] = " + this.anObjectArray2405[i]);
      }

      for(i = 0; i < this.anObjectArray2351.length; ++i) {
         System.out.println("anObjectArray2351[" + i + "] = " + this.anObjectArray2351[i]);
      }

      for(i = 0; i < this.anObjectArray2302.length; ++i) {
         System.out.println("anObjectArray2302[" + i + "] = " + this.anObjectArray2302[i]);
      }

      for(i = 0; i < this.anObjectArray2296.length; ++i) {
         System.out.println("anObjectArray2296[" + i + "] = " + this.anObjectArray2296[i]);
      }

      for(i = 0; i < this.anIntArray2452.length; ++i) {
         System.out.println("anIntArray2452[" + i + "] = " + this.anIntArray2452[i]);
      }

      for(i = 0; i < this.anIntArray2472.length; ++i) {
         System.out.println("anIntArray2472[" + i + "] = " + this.anIntArray2472[i]);
      }

      for(i = 0; i < this.anIntArray2360.length; ++i) {
         System.out.println("anIntArray2360[" + i + "] = " + this.anIntArray2360[i]);
      }

      for(i = 0; i < this.anIntArray2388.length; ++i) {
         System.out.println("anIntArray2388[" + i + "] = " + this.anIntArray2388[i]);
      }

      for(i = 0; i < this.anIntArray2299.length; ++i) {
         System.out.println("anIntArray2299[" + i + "] = " + this.anIntArray2299[i]);
      }

   }

   public Object[] decodeScript(InputStream stream) {
      int size = stream.readUnsignedByte();
      Object[] objects = new Object[size];

      for(int index = 0; ~size < ~index; ++index) {
         int i_41_ = stream.readUnsignedByte();
         if(~i_41_ == -1) {
            objects[index] = new Integer(stream.readInt());
         } else if(i_41_ == 1) {
            objects[index] = stream.readString();
         }
      }

      this.aBoolean2353 = true;
      return objects;
   }

   public int[] method2465(InputStream stream) {
      int size = stream.readUnsignedByte();
      if(size == 0) {
         return null;
      } else {
         int[] array = new int[size];

         for(int index = 0; size > index; ++index) {
            array[index] = stream.readInt();
         }

         return array;
      }
   }

   public void decodeNoscriptsFormat(InputStream stream) {
      this.useScripts = false;
      this.type = stream.readUnsignedByte();
      this.anInt2324 = stream.readUnsignedByte();
      this.anInt2441 = stream.readUnsignedShort();
      this.x = stream.readShort();
      this.y = stream.readShort();
      this.width = stream.readUnsignedShort();
      this.height = stream.readUnsignedShort();
      this.aByte2341 = 0;
      this.aByte2356 = 0;
      this.aByte2311 = 0;
      this.aByte2469 = 0;
      this.anInt2369 = stream.readUnsignedByte();
      this.parentId = stream.readUnsignedShort();
      if(~this.parentId == -65536) {
         this.parentId = -1;
      } else {
         this.parentId += this.hash & -65536;
      }

      this.anInt2448 = stream.readUnsignedShort();
      if(~this.anInt2448 == -65536) {
         this.anInt2448 = -1;
      }

      int i = stream.readUnsignedByte();
      int i_1_;
      if(~i < -1) {
         this.anIntArray2407 = new int[i];
         this.anIntArray2384 = new int[i];

         for(i_1_ = 0; i > i_1_; ++i_1_) {
            this.anIntArray2384[i_1_] = stream.readUnsignedByte();
            this.anIntArray2407[i_1_] = stream.readUnsignedShort();
         }
      }

      i_1_ = stream.readUnsignedByte();
      int i_5_;
      int is;
      int i_13_;
      if(~i_1_ < -1) {
         this.anIntArrayArray2327 = new int[i_1_][];

         for(i_5_ = 0; ~i_1_ < ~i_5_; ++i_5_) {
            is = stream.readUnsignedShort();
            this.anIntArrayArray2327[i_5_] = new int[is];

            for(i_13_ = 0; ~is < ~i_13_; ++i_13_) {
               this.anIntArrayArray2327[i_5_][i_13_] = stream.readUnsignedShort();
               if(~this.anIntArrayArray2327[i_5_][i_13_] == -65536) {
                  this.anIntArrayArray2327[i_5_][i_13_] = -1;
               }
            }
         }
      }

      if(~this.type == -1) {
         this.anInt2479 = stream.readUnsignedShort();
         this.hidden = stream.readUnsignedByte() == 1;
      }

      if(this.type == 1) {
         stream.readUnsignedShort();
         stream.readUnsignedByte();
      }

      i_5_ = 0;
      if(~this.type == -3) {
         this.anIntArray2400 = new int[this.height * this.width];
         this.aByte2341 = 3;
         this.anIntArray2418 = new int[this.height * this.width];
         this.aByte2356 = 3;
         is = stream.readUnsignedByte();
         if(is == 1) {
            i_5_ |= 268435456;
         }

         i_13_ = stream.readUnsignedByte();
         if(i_13_ == 1) {
            i_5_ |= 1073741824;
         }

         int var10 = stream.readUnsignedByte();
         stream.readUnsignedByte();
         if(~var10 == -2) {
            i_5_ |= Integer.MIN_VALUE;
         }

         this.anInt2332 = stream.readUnsignedByte();
         this.anInt2414 = stream.readUnsignedByte();
         this.anIntArray2337 = new int[20];
         this.anIntArray2323 = new int[20];
         this.anIntArray2431 = new int[20];

         int i_11_;
         for(i_11_ = 0; i_11_ < 20; ++i_11_) {
            int var12 = stream.readUnsignedByte();
            if(~var12 != -2) {
               this.anIntArray2431[i_11_] = -1;
            } else {
               this.anIntArray2323[i_11_] = stream.readShort();
               this.anIntArray2337[i_11_] = stream.readShort();
               this.anIntArray2431[i_11_] = stream.readInt();
            }
         }

         this.aStringArray2363 = new String[5];

         for(i_11_ = 0; i_11_ < 5; ++i_11_) {
            String var121 = stream.readString();
            if(~var121.length() < -1) {
               this.aStringArray2363[i_11_] = var121;
               i_5_ |= 1 << 23 + i_11_;
            }
         }
      }

      if(~this.type == -4) {
         this.aBoolean2367 = ~stream.readUnsignedByte() == -2;
      }

      if(~this.type == -5 || this.type == 1) {
         this.anInt2312 = stream.readUnsignedByte();
         this.anInt2297 = stream.readUnsignedByte();
         this.anInt2364 = stream.readUnsignedByte();
         this.anInt2375 = stream.readUnsignedShort();
         if(~this.anInt2375 == -65536) {
            this.anInt2375 = -1;
         }

         this.aBoolean2366 = stream.readUnsignedByte() == 1;
      }

      if(~this.type == -5) {
         this.aString2357 = stream.readString();
         this.aString2334 = stream.readString();
      }

      if(this.type == 1 || ~this.type == -4 || this.type == 4) {
         this.anInt2467 = stream.readInt();
      }

      if(this.type == 3 || this.type == 4) {
         this.anInt2424 = stream.readInt();
         this.anInt2451 = stream.readInt();
         this.anInt2477 = stream.readInt();
      }

      if(~this.type == -6) {
         this.imageId = stream.readInt();
         this.anInt2349 = stream.readInt();
      }

      if(~this.type == -7) {
         this.modelType = 1;
         this.modelId = stream.readUnsignedShort();
         this.anInt2301 = 1;
         if(this.modelId == '\uffff') {
            this.modelId = -1;
         }

         this.anInt2386 = stream.readUnsignedShort();
         if(~this.anInt2386 == -65536) {
            this.anInt2386 = -1;
         }

         this.anInt2443 = stream.readUnsignedShort();
         if(this.anInt2443 == '\uffff') {
            this.anInt2443 = -1;
         }

         this.anInt2298 = stream.readUnsignedShort();
         if(this.anInt2298 == '\uffff') {
            this.anInt2298 = -1;
         }

         this.anInt2403 = stream.readUnsignedShort();
         this.anInt2461 = stream.readUnsignedShort();
         this.anInt2482 = stream.readUnsignedShort();
      }

      if(~this.type == -8) {
         this.aByte2341 = 3;
         this.anIntArray2418 = new int[this.width * this.height];
         this.aByte2356 = 3;
         this.anIntArray2400 = new int[this.width * this.height];
         this.anInt2312 = stream.readUnsignedByte();
         this.anInt2375 = stream.readUnsignedShort();
         if(this.anInt2375 == '\uffff') {
            this.anInt2375 = -1;
         }

         this.aBoolean2366 = stream.readUnsignedByte() == 1;
         this.anInt2467 = stream.readInt();
         this.anInt2332 = stream.readShort();
         this.anInt2414 = stream.readShort();
         is = stream.readUnsignedByte();
         if(~is == -2) {
            i_5_ |= 1073741824;
         }

         this.aStringArray2363 = new String[5];

         for(i_13_ = 0; i_13_ < 5; ++i_13_) {
            String var101 = stream.readString();
            if(var101.length() > 0) {
               this.aStringArray2363[i_13_] = var101;
               i_5_ |= 1 << i_13_ + 23;
            }
         }
      }

      if(~this.type == -9) {
         this.aString2357 = stream.readString();
      }

      if(this.anInt2324 == 2 || ~this.type == -3) {
         this.aString2463 = stream.readString();
         this.aString2373 = stream.readString();
         is = 63 & stream.readUnsignedShort();
         i_5_ |= is << -116905845;
      }

      if(~this.anInt2324 == -2 || ~this.anInt2324 == -5 || this.anInt2324 == 5 || this.anInt2324 == 6) {
         this.aString2329 = stream.readString();
         if(~this.aString2329.length() == -1) {
            if(~this.anInt2324 == -2) {
               this.aString2329 = "Ok";
            }

            if(~this.anInt2324 == -5) {
               this.aString2329 = "Select";
            }

            if(~this.anInt2324 == -6) {
               this.aString2329 = "Select";
            }

            if(~this.anInt2324 == -7) {
               this.aString2329 = "Continue";
            }
         }
      }

      if(this.anInt2324 == 1 || this.anInt2324 == 4 || ~this.anInt2324 == -6) {
         i_5_ |= 4194304;
      }

      if(~this.anInt2324 == -7) {
         i_5_ |= 1;
      }

      this.settings = new IComponentSettings(i_5_, -1);
      System.out.println("useScripts = " + this.useScripts);
      System.out.println("type = " + this.type);
      System.out.println("anInt2324 = " + this.anInt2324);
      System.out.println("anInt2441 = " + this.anInt2441);
      System.out.println("x = " + this.x);
      System.out.println("y = " + this.y);
      System.out.println("width = " + this.width);
      System.out.println("height = " + this.height);
      System.out.println("anInt2369 = " + this.anInt2369);
      System.out.println("parentId = " + this.parentId);
      System.out.println("anInt2448 = " + this.anInt2448);

      byte var11;
      for(var11 = 0; var11 < this.anIntArray2407.length; ++i) {
         System.out.println("anIntArray2407[" + var11 + "] = " + this.anIntArray2407[var11]);
      }

      for(var11 = 0; var11 < this.aStringArray2363.length; ++i) {
         System.out.println("aStringArray2363[" + var11 + "] = " + this.aStringArray2363[var11]);
      }

   }

   public static int method2412(int arg0) {
      return 127 & arg0 >> -809958741;
   }
}
