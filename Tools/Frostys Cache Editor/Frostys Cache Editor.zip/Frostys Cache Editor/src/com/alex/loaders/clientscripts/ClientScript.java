package com.alex.loaders.clientscripts;

public class ClientScript {
}
